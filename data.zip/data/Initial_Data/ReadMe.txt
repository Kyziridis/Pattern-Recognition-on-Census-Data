####### README.txt

##Folder /data/Initial_Data/

Directory contains only two files : "census-income.data" and "names_for_R.csv".

The latter is exported by us for terms of simplicity using this file for variable names.


